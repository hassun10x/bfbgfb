// العناصر
const playerNameInput = document.getElementById('playerNameInput');
const setNameButton = document.getElementById('setNameButton');
const playerNameDisplay = document.getElementById('playerNameDisplay');
const bellButton = document.getElementById('bellButton');
const timerDisplay = document.getElementById('timer');
const resetTimerButton = document.getElementById('resetTimerButton');
const resetCountersButton = document.getElementById('resetCountersButton');
const increaseButton = document.getElementById('increaseButton');
const decreaseButton = document.getElementById('decreaseButton');
const scoreDisplay = document.getElementById('score');
const counters = document.querySelectorAll('.counter');
const progressBar = document.getElementById('progress');
const warningButtons = document.querySelectorAll('.warning-button');
const warningMessage = document.getElementById('warningMessage');

// المتغيرات
let timeLeft = 10;
let score = 0;
let timerInterval;
let playerName = '';
let selectedCounters = [];
let warnings = 0;
let canSelectCounter = true; // للتحكم في تحديد التعدادات كل 15 ثانية
let canPressScoreButtons = true; // للتحكم في الضغط على أزرار النقاط

// ملف الصوت
const audio = new Audio('sound.mp3'); // تأكد من وجود ملف sound.mp3 في نفس المجلد
let isPlaying = false; // لتتبع حالة الصوت

// تثبيت اسم اللاعب
setNameButton.addEventListener('click', () => {
    playerName = playerNameInput.value.trim();
    if (playerName) {
        playerNameDisplay.textContent = `اللاعب: ${playerName}`;
        playerNameDisplay.style.display = 'block';
        playerNameInput.style.display = 'none';
        setNameButton.style.display = 'none';
    }
});

// بدء العداد
function startTimer() {
    timerInterval = setInterval(() => {
        timeLeft--;
        timerDisplay.textContent = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            bellButton.disabled = true;
            resetTimerButton.disabled = false; // تمكين زر إعادة ضبط الموقت
        }
    }, 1000);
}

// إعادة ضبط الموقت
function resetTimer() {
    clearInterval(timerInterval);
    timeLeft = 10;
    timerDisplay.textContent = timeLeft;
    bellButton.disabled = false;
    resetTimerButton.disabled = true; // تعطيل زر إعادة ضبط الموقت
}

// إعادة ضبط التعدادات
function resetCounters() {
    selectedCounters = [];
    counters.forEach(counter => {
        counter.classList.remove('selected');
        counter.disabled = false;
    });
    canSelectCounter = true; // تمكين تحديد التعدادات
    progressBar.style.width = '0'; // إعادة ضبط بار التقدم

    // إعادة ضبط الإنذارات
    warnings = 0;
    warningButtons.forEach(button => {
        button.classList.remove('selected', 'yellow', 'red');
        button.classList.add('white');
        button.disabled = button.classList.contains('red'); // تعطيل الأحمر فقط
    });
}

// زيادة النقاط
function increaseScore() {
    if (score < 100 && canPressScoreButtons) {
        score++;
        updateScore();
        disableScoreButtons();
    }
}

// نقصان النقاط
function decreaseScore() {
    if (score > -100 && canPressScoreButtons) {
        score--;
        updateScore();
        disableScoreButtons();
    }
}

// تحديث النقاط
function updateScore() {
    if (score < 0) {
        scoreDisplay.textContent = `النقاط -${Math.abs(score)}`;
        scoreDisplay.classList.remove('positive');
        scoreDisplay.classList.add('negative');
    } else {
        scoreDisplay.textContent = `النقاط ${score}`;
        scoreDisplay.classList.remove('negative');
        scoreDisplay.classList.add('positive');
    }
}

// تعطيل أزرار النقاط لمدة 15 ثانية
function disableScoreButtons() {
    canPressScoreButtons = false;
    increaseButton.disabled = true;
    decreaseButton.disabled = true;

    setTimeout(() => {
        canPressScoreButtons = true;
        increaseButton.disabled = false;
        decreaseButton.disabled = false;
    }, 15000); // 15 ثانية
}

// تشغيل أو إيقاف الصوت
function toggleAudio() {
    if (isPlaying) {
        audio.pause();
        audio.currentTime = 0; // إعادة الصوت إلى البداية
    } else {
        audio.play();
    }
    isPlaying = !isPlaying; // تبديل حالة الصوت
}

// تفاعلات الأزرار
bellButton.addEventListener('click', () => {
    toggleAudio(); // تشغيل أو إيقاف الصوت
    startTimer();
    bellButton.disabled = true; // تعطيل الزر بعد الضغط
});

resetTimerButton.addEventListener('click', resetTimer);

resetCountersButton.addEventListener('click', resetCounters);

increaseButton.addEventListener('click', increaseScore);

decreaseButton.addEventListener('click', decreaseScore);

// اختيار التعدادات
counters.forEach(counter => {
    counter.addEventListener('click', () => {
        if (canSelectCounter) {
            const value = parseInt(counter.getAttribute('data-value'));
            if (!selectedCounters.includes(value)) {
                selectedCounters.push(value);
                counter.classList.add('selected');
                counter.disabled = true; // تعطيل التعداد بعد الاختيار
                canSelectCounter = false; // تعطيل تحديد التعدادات مؤقتًا

                // بدء بار التقدم
                let progress = 0;
                const progressInterval = setInterval(() => {
                    progress += 1;
                    progressBar.style.width = `${progress}%`;

                    if (progress >= 100) {
                        clearInterval(progressInterval);
                        canSelectCounter = true; // تمكين تحديد التعدادات بعد 15 ثانية
                    }
                }, 150); // 150 مللي ثانية لكل 1% (15 ثانية إجماليًا)
            }

            // إذا تم اختيار 5 تعدادات
            if (selectedCounters.length === 5) {
                increaseScore(); // زيادة النقاط تلقائيًا
                resetCounters(); // إعادة ضبط التعدادات
            }
        }
    });
});

// إدارة الإنذارات
warningButtons.forEach(button => {
    button.addEventListener('click', () => {
        if (!button.classList.contains('selected')) {
            button.classList.add('selected');
            warnings++;

            if (warnings === 1) {
                button.classList.remove('white');
                button.classList.add('yellow');
                warningButtons[1].disabled = false; // تمكين الإنذار الأحمر بعد الإنذار الأصفر
            }

            if (warnings === 2) {
                button.classList.remove('white');
                button.classList.add('red');
                warningMessage.textContent = 'إنذاران! تم خصم نقطة.';
                warningMessage.style.display = 'block';
                decreaseScore(); // خصم نقطة تلقائيًا
                warnings = 0; // إعادة ضبط الإنذارات
                warningButtons.forEach(btn => {
                    btn.classList.remove('selected', 'yellow', 'red');
                    btn.classList.add('white');
                    btn.disabled = btn.classList.contains('red'); // تعطيل الأحمر فقط
                });
                setTimeout(() => {
                    warningMessage.style.display = 'none';
                }, 2000);
            }
        }
    });
});